const { createClient } = require('@supabase/supabase-js');
try {
  const supabase = createClient('https://qjobrkzefvheypzlwpex.supabase.co', 'sb_publishable_UYSfhDQhHcXM4IQt5t_H2Q_b4yXsEeV');
  console.log("Client created successfully!");
} catch (e) {
  console.log("Error creating client:", e.message);
}
